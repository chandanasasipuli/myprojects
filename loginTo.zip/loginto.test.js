//Below tests will check store spec files on respective resolution 

this.LoginPage = function(driver) {
	GalenPages.extendPage(this, driver, "login page", {
		emailTextfield : "xpath: //input[@id='EmailAddress']", 
		passwordTextfield : "xpath: //input[@id='Password']", 
		submitButton : "xpath: //a[@id='loginsubmit']"
	});
};

this.IntroPage = function(driver) {
	GalenPages.extendPage(this, driver, "login page", {
		emailtextfieldintro : "id: EmailAddress",
		passwordTextfieldintro : "id: Password",
		submitButtonIntro : "id: loginsubmit"
	});
};

function sleep(delay) {
	var start = new Date().getTime();
	while (new Date().getTime() < start + delay);
}

var propertyFile = loadProperties("localconfig.properties");

//var baseUrl;
var driver;

forAll([ [ "Desktop", "Desktop", "1920x1080" ],
		[ "Galaxy s7", "Galaxy s7 Landscape", "640x360" ],
		[ "Galaxy Tab Pro", "Galaxy Tab Pro Landscape", "1280x800" ],
		[ "Iphone 7 6 6s", "Iphone 7 6 6s", "375x667" ],
		[ "Iphone 5", "Iphone 5", "320x480" ],
		[ "Ipad", "Ipad", "768x1024" ],
		[ "Ipad", "Ipad Landscape", "1024x768" ],
		[ "Ipad Pro", "Ipad Pro Landscape", "1366x1024" ],
		[ "Iphone 6+ 6s+", "Iphone 6+ 6s+", "414x736" ],
		[ "Iphone 6+ 6s+", "Iphone 6+ 6s+ Landscape", "736x414" ] ], function(deviceName,
		tagName, size) {

	test("Test Loginto page spec file on " + deviceName + " in " + tagName
			+ " mode with size " + size + " on " + propertyFile.get("env"),
			function() {
				try {

					if (propertyFile.get("env").equals("production")) {
						//baseUrl = "https://www.snapfish.com/photo-gift/loginto"
						logged("In Prduction Environment", function() {
						});
						// 
						//driver = createDriver(baseUrl+"/beta-welcome",size,"firefox");
						//driver = createGridDriver(propertyFile.get("grid")+ "/wd/hub", {
						driver = createGridDriver("http://localhost:4444/wd/hub", {
						//driver = createDriver(baseUrl, {
							browser : "firefox",
							size : size
						});

					} 

					GalenPages.sleep(5000);
					
					var login = new LoginPage(driver);
					//driver.get(propertyFile.get("baseUrl")+"/photo-gift/loginto");
					driver.get("https://www.snapfish.com/photo-gift/loginto");
					logged("In LogInto Page", function() {
					});
					GalenPages.sleep(5000);
					logged("Spec Starting", function() {
					});
					//checkLayout(driver, "sample_loginTo.gspec", [ tagName ]);
					checkLayout(driver, "loginTo.gspec", [ tagName ]);
					//checkLayout(driver, "checkloginto.gspec", [ tagName ]);
					logged("Spec File Execution Ended", function() {
					});

				} catch (e) {
					logged("The Error is at" + e.stack, function() {
					});
					e.stack();
				} finally {
					driver.quit();
				}

			});
});
