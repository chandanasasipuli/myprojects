var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "/res/views/login.html"
    })
    .when('/adminlogin', {
    	resolve: {
    		"check": function($location,$rootScope){
    			if(!$rootScope.loggedin)
    				{
    				$location.path('/');
    				}
    		}
    	},
        templateUrl : "/res/views/admindashboard.html"
       
    })
     .when('/employeelogin', {
    	resolve: {
    		"check": function($location,$rootScope){
    			if(!$rootScope.loggedin)
    				{
    				$location.path('/');
    				}
    		}
    	},
        templateUrl : "/res/views/employeedashboard.html"
       
    })
     .when('/managerlogin', {
    	resolve: {
    		"check": function($location,$rootScope){
    			if(!$rootScope.loggedin)
    				{
    				$location.path('/');
    				}
    		}
    	},
        templateUrl : "/res/views/managerdashboard.html"
       
    })
    .otherwise({
    	redirectTo: '/'
    });
    
    
});
app.controller('loginController', function($scope, $location,$http,$rootScope) {
    $scope.submit=function(){
    	var flag;
    	
    	var username=$scope.uname;
    	var pass=$scope.password;
    	var role=$scope.role;
    	alert(role);
    	$scope.username="";
    	/*if($scope.uname=="raja" && $scope.password=="raja1234")
    		{
    		alert("success");
    		$location.path('/login');
    	//	$scope.$apply();
    		}
    	else
    		{
    		alert("Please provide correct username and password")
    		}*/
    	$.ajax({  
    		type : "GET",  
    		url : "userlogin",  
    		data : {"uname" : username,"pass":pass,"role":role},
    		dataType : 'text',
    		beforeSend: function(xhr) {  
    			xhr.setRequestHeader("Accept", "application/json");  
    			xhr.setRequestHeader("Content-Type", "application/json;charset=utf-8");
    			
    		},  
    		success : function(response) {
    			alert("reached");
    			if(response=="passed")
    				{
    				
    				alert("passed");
    				flag=true;
    				$rootScope.loggedin=flag;
    				if(role=="Employee")
    					{
    				window.location.assign("/login/#/employeelogin");
    					}
    				else if(role=="Manager")
					{
				window.location.assign("/login/#/managerlogin");
					}
    				else if(role=="Admin")
					{
				window.location.assign("/login/#/adminlogin");
					}
    				}
    			else
    				{
    				
    				alert("failed");
    				flag=false;
    				$rootScope.loggedin=flag;
    				alert("Please enter correct credentials");
    				}
    			alert($rootScope.loggedin);	
    			
    		},  
    		error : function(e,status) {
    			alert("error");
    			alert(status);
    			
    		}  

    	}); 
    	/*$http({
    		  method: 'GET',
    		  url: 'login',
    		data : {"uname" : username,"pass":pass},
    	    dataType : 'text',
    	    headers : {'Content-Type':'application/json;charset=utf-8','Accept':'application/json'}
    		}).then(function successCallback(response) {
    		    alert("success");
    		  }, function errorCallback(response) {
    		    // called asynchronously if an error occurs
    		    // or server returns response with an error status.
    			  alert(response.status);
    		  });*/
    	
   	 	alert($rootScope.loggedin);
    	
    };
});