package com.valuelabs.lms.service;

import java.util.List;

import com.valuelabs.lms.dao.LoginDao;
import com.valuelabs.lms.dao.LoginDaoImpl;
import com.valuelabs.lms.model.Employee;
import com.valuelabs.lms.util.HibernateConnector;

public class LoginServiceImpl implements LoginService{
	LoginDao emp;
	HibernateConnector con;
	@Override
	public List<Employee> getallEmployee() {
		emp= (LoginDao) new LoginDaoImpl();
		con= new HibernateConnector();
		List list=emp.getAllEmployees(con.getConnection());
		
		return list;
	}
	@Override
	public boolean checkEmployeeLoginCredentials(String username, String password,String role) {
		emp= (LoginDao) new LoginDaoImpl();
		con= new HibernateConnector();
		List list=emp.checkLoginCredentials(con.getConnection(),username,password);
		//System.out.println(list.get(0));
		if(list.isEmpty())
		{
			
			return false;
		}
		else if(list.get(0).toString().equalsIgnoreCase(role))
		{
		return true;
		}
		return false;
	}
	
	

}
