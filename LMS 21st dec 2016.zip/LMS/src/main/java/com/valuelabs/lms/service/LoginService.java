package com.valuelabs.lms.service;

import java.util.List;

import com.valuelabs.lms.model.Employee;

public interface LoginService {
	List<Employee> getallEmployee();
	boolean checkEmployeeLoginCredentials(String username, String password,String role);

}
