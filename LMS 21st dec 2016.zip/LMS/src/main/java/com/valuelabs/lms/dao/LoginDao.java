package com.valuelabs.lms.dao;

import java.util.List;

import org.hibernate.Session;

import com.valuelabs.lms.model.Employee;

public interface LoginDao {
	
	List<Employee> getAllEmployees(Session session);
	List<Employee> checkLoginCredentials(Session session,String username,String password);
	
	
}
