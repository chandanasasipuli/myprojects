package com.valuelabs.lms.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.valuelabs.lms.model.Employee;

public class LoginDaoImpl implements LoginDao {
	@Override
	public List<Employee> getAllEmployees(Session session)
	{
		Query query=session.createQuery("from Employee");
		List list=query.list();
		session.close();
		
		return list;
		
	}

	@Override
	public List<Employee> checkLoginCredentials(Session session,String username,String password) {
		String hql="Select emp.role from Employee emp where emp.empname=:empname and emp.password=:password";
		Query query=session.createQuery(hql);
		query.setParameter("empname", username);
        query.setParameter("password", password);
		List list=query.list();
		session.close();
		
		return list;
	}

	/**/

}
