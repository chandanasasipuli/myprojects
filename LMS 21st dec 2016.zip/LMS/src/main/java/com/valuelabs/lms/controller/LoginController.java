package com.valuelabs.lms.controller;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.valuelabs.lms.dao.LoginDao;
import com.valuelabs.lms.dao.LoginDaoImpl;
import com.valuelabs.lms.model.Employee;
import com.valuelabs.lms.service.LoginService;
import com.valuelabs.lms.service.LoginServiceImpl;
import com.valuelabs.lms.util.HibernateConnector;

@Controller
@RequestMapping("/login")
public class LoginController {
	Session session;
	@RequestMapping("/")
	public String homepage()
	{
		System.out.println("asdfh");
		return "login";
	}
	
	@RequestMapping("/showdetails")
	public ModelAndView showdetails()
	{
		ModelAndView m= new ModelAndView();
		/*HibernateConnector con=new HibernateConnector();
		session=con.getConnection();
		EmployeeDetails emp = (EmployeeDetails) new EmployeeDetailsImpl();*/
		LoginService empinfo= new LoginServiceImpl();
		//List<Employee> list= emp.getAllEmployees(session);
		List<Employee> list= empinfo.getallEmployee();
		Iterator<Employee> it= list.iterator();
		while(it.hasNext())
		{
			
			Employee emp1=it.next();
			System.out.println(emp1.getEmpid());
			System.out.println(emp1.getEmpname());
		}
		m.setViewName("show");
		m.addObject("list", list);
		return m;
	}
	@RequestMapping(value = "/userlogin", method = RequestMethod.GET)	
	public @ResponseBody String checkLoginCredentials(@RequestParam("uname") String username, @RequestParam("pass") String password,@RequestParam("role") String role) {
		System.out.println("1");
		LoginService empinfo= new LoginServiceImpl();
		System.out.println(username+" "+password);
		String result;
		if(empinfo.checkEmployeeLoginCredentials(username, password,role))
		{
			result="passed";
		}
		else
		{
			result="failed";
		}
		System.out.println(result);
		return result;
	    
	}

}
