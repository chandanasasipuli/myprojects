package com.valuelabs.lms.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:log4j.properties")
public class Log4J {

}
