package com.valuelabs.lms.dao;

import java.util.List;

public interface LoginDao {

	List<String> checkLoginCredentials(String username, String password);

}
