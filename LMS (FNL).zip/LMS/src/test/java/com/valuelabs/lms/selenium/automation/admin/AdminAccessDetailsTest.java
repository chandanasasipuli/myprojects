package com.valuelabs.lms.selenium.automation.admin;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;



public class AdminAccessDetailsTest {

	public static void main(String arg[]) throws InterruptedException{
		WebDriver driver  = new FirefoxDriver();
		
		String Url = "http://172.22.151.203:8088/login/";		
		driver.navigate().to(Url);
		driver.manage().window().maximize();
		
		Select dropDown1 = new Select(driver.findElement(By.id("selectROle")));
		dropDown1.selectByVisibleText("Admin");		
		driver.findElement(By.id("uname")).sendKeys("vlsp1");
		driver.findElement(By.id("password")).sendKeys("admin123");		
		driver.findElement(By.id("submitBtn")).click();		
		Thread.sleep(3000);		
		
		driver.findElement(By.xpath(".//*[@id='accessEmployeeDetailsFromAdminBtn']")).click();		
		Thread.sleep(3000);	
		//Editing 4th record of employee
		driver.findElement(By.xpath("//table[@class='table main_table table-striped table-hover']/tbody/tr[4]/td[6]")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("employeeNameInput")).clear();		
		Thread.sleep(3000);
		
		driver.findElement(By.id("employeeNameInput")).sendKeys("ChandanasasiPuli");		
		driver.findElement(By.id("emailInput")).clear();
		Thread.sleep(3000);
		
		driver.findElement(By.id("emailInput")).sendKeys("chandu@vl.com");		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//button[text( )='update']")).click();
		driver.switchTo().alert().accept();
		
		Thread.sleep(3000);	
		
		//Deleting 5th record of employee
		driver.findElement(By.xpath("//table[@class='table main_table table-striped table-hover']/tbody/tr[5]/td[7]")).click();
		
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		
		driver.quit();	
		

		
	}
	
}
