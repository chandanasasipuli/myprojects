package com.valuelabs.lms.selenium.automation.admin;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class AdminUpdatePasswordTest {
	public static void main(String arg[]) throws InterruptedException {
		WebDriver driver = new FirefoxDriver();
		driver.get("http://172.22.151.203:8088/login/");
		driver.manage().window().maximize();

		Select dropDown1 = new Select(driver.findElement(By.id("selectROle")));
		dropDown1.selectByVisibleText("Admin");

		driver.findElement(By.id("uname")).sendKeys("vlsp1");
		driver.findElement(By.id("password")).sendKeys("admin123");
		driver.findElement(By.id("submitBtn")).click();
		Thread.sleep(3000);	
		
		driver.findElement(By.id("updatePasswordBtn")).click();
		Thread.sleep(3000);	
		//Reset Password button testing 
		
		driver.findElement(By.id("empId")).sendKeys("vlsp1489");
		driver.findElement(By.id("newPassword")).sendKeys("123456");
		driver.findElement(By.id("reEnterPassword")).sendKeys("123456");		
		
		driver.findElement(By.xpath("//button[text()='Reset Password']")).click();		
		Thread.sleep(3000);		
		driver.switchTo().alert().accept();
		
		
		//Update password cancel button testing 
		
		driver.findElement(By.id("empId")).sendKeys("vlsp1489");
		driver.findElement(By.id("newPassword")).sendKeys("123456");
		driver.findElement(By.id("reEnterPassword")).sendKeys("123456");		
		
		driver.findElement(By.xpath("//input[@id='reset']")).click();		
		Thread.sleep(3000);		
		
		
		
		driver.findElement(By.xpath("//span[text()='Services']"));
		

		driver.findElement(By.xpath("//a[text()='Access Details']")).click();
		Thread.sleep(3000);
		driver.close();

	}
}
