package com.valuelabs.lms.selenium.automation.admin;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
public class AdminAccessPermissionTest {

	public static void main(String arg[]) throws InterruptedException{
		WebDriver driver  = new FirefoxDriver();
		
		String Url = "http://172.22.151.203:8088/login/";	
		driver.navigate().to(Url);
		driver.manage().window().maximize();		
		Select dropDown1 = new Select(driver.findElement(By.id("selectROle")));
		dropDown1.selectByVisibleText("Admin");		
		driver.findElement(By.id("uname")).sendKeys("vlsp1");
		driver.findElement(By.id("password")).sendKeys("admin123");		
		driver.findElement(By.id("submitBtn")).click();		
		Thread.sleep(3000);	
		
		
		driver.findElement(By.xpath("//*[@id='accessPermissionFromAdminBtn']")).click();		
		Thread.sleep(3000);	
		
		Select dropDown2 = new Select(driver.findElement(By.id("selectRole")));
		dropDown2.selectByVisibleText("Employee");
		Thread.sleep(3000);	
		driver.findElement(By.id("empName")).sendKeys("ddd");	
		driver.findElement(By.id("empId")).sendKeys("ddd");Thread.sleep(3000);	

		driver.findElement(By.id("password")).sendKeys("ddd");
				
		driver.findElement(By.id("email")).sendKeys("ddd@vl.com");	
		driver.findElement(By.id("manager")).sendKeys("vlsp1111");		
		Thread.sleep(3000);	
		driver.findElement(By.xpath("//button[text( )='Submit']")).click();
		Thread.sleep(3000);	
		driver.switchTo().alert().accept();	
		Thread.sleep(3000);	
		driver.close();			
	}
	
}
