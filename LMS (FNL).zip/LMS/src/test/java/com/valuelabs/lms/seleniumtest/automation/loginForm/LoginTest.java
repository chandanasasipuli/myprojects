package com.valuelabs.lms.seleniumtest.automation.loginForm;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class LoginTest {

	public static void main(String arg[]) throws InterruptedException {
		WebDriver driver = new FirefoxDriver();
		
		String url = "http://172.22.151.203:8088/login/";
		driver.get(url);
		driver.manage().window().maximize();

		//Admin login test
		Select dropDown1 = new Select(driver.findElement(By.id("selectROle")));
		dropDown1.selectByVisibleText("Admin");

		driver.findElement(By.id("uname")).sendKeys("vlsp1");
		driver.findElement(By.id("password")).sendKeys("admin123");
		driver.findElement(By.id("submitBtn")).click();
		Thread.sleep(3000);
		//Manager Longin test
		driver.get(url);
		Select dropDown2 = new Select(driver.findElement(By.id("selectROle")));
		dropDown2.selectByVisibleText("Manager");

		driver.findElement(By.id("uname")).sendKeys("vlsp1111");
		driver.findElement(By.id("password")).sendKeys("vlsp1111");
		driver.findElement(By.id("submitBtn")).click();
		Thread.sleep(3000);
		
		driver.get(url);
		Select dropDown3 = new Select(driver.findElement(By.id("selectROle")));
		dropDown3.selectByVisibleText("Employee");
		driver.findElement(By.id("uname")).sendKeys("vlsp1489");
		driver.findElement(By.id("password")).sendKeys("123456");
		driver.findElement(By.id("submitBtn")).click();
		Thread.sleep(3000);
		
		driver.quit();
	}
}
