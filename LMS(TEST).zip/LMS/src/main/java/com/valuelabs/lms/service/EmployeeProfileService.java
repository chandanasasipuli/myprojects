package com.valuelabs.lms.service;

import com.valuelabs.lms.bean.EmployeeBean;

public interface EmployeeProfileService {

	public boolean saveEmployeeDetails(EmployeeBean employeeBean);
}
