package com.valuelabs.lms.bean;

public class EmployeeBean {
	
	private String empId;
	private String firtsName;
	private String lastName;
	private String fatherName;
	private String mobNo;
	private String alMobNo;
	private String address;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getFirtsName() {
		return firtsName;
	}
	public void setFirtsName(String firtsName) {
		this.firtsName = firtsName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public String getAlMobNo() {
		return alMobNo;
	}
	public void setAlMobNo(String alMobNo) {
		this.alMobNo = alMobNo;
	}
	
	
}
